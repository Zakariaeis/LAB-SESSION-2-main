

function valid() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var login = 3;
    if (username == "admin" && password == "admin") {
        alert("Login Corrcet");
        window.open("http://localhost:63342/LAB-SESSION-2-main/admin.html?_ijt=mec08landub0l1e145h8o2dqvl");
    } else{
        alert("False")

    }

    for (var i =3 ; i=0; i--){
        if(username != "admin" || password != "admin"){
            login=login-1;
        }
        if (login==0){
            alert("hnbsakj");
        }
    }
}

function ageCalculator() {
    var userinput = document.getElementById("DOB").value;
    var dob = new Date(userinput);
    if(userinput==null || userinput=='') {
        document.getElementById("message").innerHTML = "**Choose a date please!";
        return false;
    } else {

        //calculate month difference from current date in time
        var month_diff = Date.now() - dob.getTime();

        //convert the calculated difference in date format
        var age_dt = new Date(month_diff);

        //extract year from date
        var year = age_dt.getUTCFullYear();

        //now calculate the age of the user
        var age = Math.abs(year - 1970);
        if(age <= 17 || age > 60){
            alert("your age  must be between 17 and 60");
        }

    }
}
//when i write wether the id or the email everything goes ok but when i write the both it doesnt
//work
function addd() {
     var id = document.getElementById("username").value;
     var fn = document.getElementById("password").value;
     var ln = document.getElementById("Lastname").value;
     var dob = document.getElementById("DOB").value;
     var gender = document.getElementById("gender").value;
     var departement = document.getElementById("depart").value;
     var email = document.getElementById("Email").value;
     var join = document.getElementById("joinday").value;






     var table = document.getElementById("table");
     var row = table.insertRow(1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    var cell6 = row.insertCell(5);
    var cell7 = row.insertCell(6);
    var cell8 = row.insertCell(7);


    cell1.innerHTML = id;
    cell2.innerHTML = fn;
    cell3.innerHTML = ln;
    cell4.innerHTML = dob;
    cell5.innerHTML = gender;
    cell6.innerHTML = departement;
    cell7.innerHTML=email;
    cell8.innerHTML=join;

    ageCalculator();

}


function filter() {
    var input, filter, table, tr, td, i;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("table");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[5];
        if (td) {
            if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
}

